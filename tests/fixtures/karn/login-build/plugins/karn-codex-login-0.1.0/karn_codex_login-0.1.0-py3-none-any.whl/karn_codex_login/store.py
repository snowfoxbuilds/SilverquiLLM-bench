"""The per-Stack login store: file guards, capture, atomic writes, and the commit rule.

The stored document is the plugin secret ``login.<stack>``; the state directory
holds only bookkeeping and the working directory (LOGIN-PLUGINS.md). A refusal's
message is a reason code and never carries login-file bytes (ADR-0093).
"""

from __future__ import annotations

import base64
import binascii
import contextlib
import fcntl
import json
import math
import os
import stat
import uuid
from pathlib import Path

from ozolith_plugin_sdk import CallbackError

LOGIN_FILE = "auth.json"
ACCOUNT_FILE = None
ACCOUNT_KEYS = frozenset()
STORED_FILES = frozenset({LOGIN_FILE})
MAX_AUTH = 1024 * 1024
# The Node Daemon's SECRET_LIMIT: the largest value set_secret accepts, in UTF-8 bytes.
SECRET_LIMIT = 65536
DOCUMENT_FORMAT = 1
LOCK_FILE = "store.lock"


class LoginError(ValueError):
    """A refusal whose message is a reason code and never contains login-file bytes."""


def validate_login(data: bytes) -> bool:
    """Whether ``data`` is a Codex login file: a strict JSON object with a full ChatGPT token."""
    if len(data) > MAX_AUTH:
        return False

    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ValueError
            result[key] = value
        return result

    def constant(_):
        raise ValueError

    def finite(text):
        value = float(text)
        if not math.isfinite(value):
            raise ValueError
        return value

    try:
        value = json.loads(
            data, object_pairs_hook=pairs, parse_constant=constant, parse_float=finite
        )
    except (ValueError, UnicodeError, RecursionError):
        return False
    if not isinstance(value, dict):
        return False
    token = value.get("tokens")
    return (
        value.get("auth_mode") in (None, "chatgpt")
        and value.get("OPENAI_API_KEY") is None
        and isinstance(token, dict)
        and all(
            isinstance(token.get(k), str) and token[k]
            for k in ("access_token", "refresh_token", "id_token", "account_id")
        )
    )


def canonical(value) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)


def private_directory(path) -> int:
    """Open ``path`` and return its descriptor once it is a private directory of this user."""
    path = Path(path)
    if not path.is_absolute() or path.resolve() != path:
        raise LoginError("unsafe_directory")
    try:
        descriptor = os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    except OSError:
        raise LoginError("private_directory_required") from None
    info = os.fstat(descriptor)
    if info.st_uid != os.getuid() or stat.S_IMODE(info.st_mode) != 0o700:
        os.close(descriptor)
        raise LoginError("private_directory_required")
    return descriptor


def read_file(root, name, *, optional=False) -> bytes | None:
    """Read one regular, unaliased file of at most ``MAX_AUTH`` bytes from a private directory."""
    descriptor = private_directory(root)
    try:
        try:
            fd = os.open(name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=descriptor)
        except FileNotFoundError:
            if optional:
                return None
            raise LoginError("missing_login") from None
        except OSError:
            raise LoginError("unsafe_login_file") from None
        with os.fdopen(fd, "rb") as source:
            info = os.fstat(source.fileno())
            if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
                raise LoginError("unsafe_login_file")
            data = source.read(MAX_AUTH + 1)
            if len(data) > MAX_AUTH:
                raise LoginError("login_file_too_large")
            return data
    finally:
        os.close(descriptor)


def capture(directory) -> dict[str, str]:
    """The login files of ``directory`` as ``{leaf: base64}``, validated and trimmed."""
    login = read_file(directory, LOGIN_FILE)
    if not validate_login(login):
        raise LoginError("invalid_login")
    result = {LOGIN_FILE: base64.b64encode(login).decode()}
    if ACCOUNT_FILE is not None:
        account = read_file(directory, ACCOUNT_FILE, optional=True)
        if account is not None:
            try:
                value = json.loads(account)
                if not isinstance(value, dict):
                    raise ValueError
                selected = {key: value[key] for key in ACCOUNT_KEYS if key in value}
                encoded = canonical(selected).encode()
            except (ValueError, UnicodeError, RecursionError):
                raise LoginError("invalid_account_metadata") from None
            result[ACCOUNT_FILE] = base64.b64encode(encoded).decode()
    return result


def write_atomic(descriptor: int, name: str, data: bytes) -> None:
    """Replace ``name`` in the open directory with ``data`` through a private temp file."""
    temporary = ".karn-auth-" + uuid.uuid4().hex
    fd = os.open(
        temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600, dir_fd=descriptor
    )
    try:
        with os.fdopen(fd, "wb") as target:
            target.write(data)
            target.flush()
            os.fsync(target.fileno())
        os.replace(temporary, name, src_dir_fd=descriptor, dst_dir_fd=descriptor)
        os.fsync(descriptor)
    finally:
        with contextlib.suppress(FileNotFoundError):
            os.unlink(temporary, dir_fd=descriptor)


def write_files(directory, files: dict[str, str]) -> None:
    """Write stored files into a private directory, each atomically with mode ``0600``."""
    descriptor = private_directory(directory)
    try:
        for name, encoded in files.items():
            if name not in STORED_FILES:
                raise LoginError("invalid_stored_file")
            try:
                data = base64.b64decode(encoded, validate=True)
            except (binascii.Error, ValueError, TypeError):
                raise LoginError("stored_login_invalid") from None
            write_atomic(descriptor, name, data)
    finally:
        os.close(descriptor)


def write_private(directory, name: str, data: bytes) -> None:
    """Write one bookkeeping file into a private directory, atomically with mode ``0600``."""
    descriptor = private_directory(directory)
    try:
        write_atomic(descriptor, name, data)
    finally:
        os.close(descriptor)


def encode_document(files: dict[str, str]) -> str:
    """A fresh stored document for ``files``, drawing a new revision."""
    if set(files) - STORED_FILES or LOGIN_FILE not in files:
        raise LoginError("invalid_stored_file")
    document = canonical(
        {
            "format": DOCUMENT_FORMAT,
            "revision": uuid.uuid4().hex,
            "files": dict(sorted(files.items())),
        }
    )
    if len(document.encode()) > SECRET_LIMIT:
        raise LoginError("login_too_large")
    return document


def decode_document(text) -> tuple[str, dict[str, str]]:
    """The revision and files of a stored document, or ``stored_login_invalid``."""
    try:
        if not isinstance(text, str) or len(text.encode()) > SECRET_LIMIT:
            raise ValueError
        value = json.loads(text)
        if not isinstance(value, dict) or set(value) != {"format", "revision", "files"}:
            raise ValueError
        revision, files = value["revision"], value["files"]
        if (
            value["format"] != DOCUMENT_FORMAT
            or not isinstance(revision, str)
            or len(revision) != 32
            or any(c not in "0123456789abcdef" for c in revision)
            or not isinstance(files, dict)
            or set(files) - STORED_FILES
            or LOGIN_FILE not in files
        ):
            raise ValueError
        decoded = {}
        for name, encoded in files.items():
            if not isinstance(encoded, str):
                raise ValueError
            data = base64.b64decode(encoded, validate=True)
            decoded[name] = base64.b64encode(data).decode()
        if not validate_login(base64.b64decode(decoded[LOGIN_FILE])):
            raise ValueError
    except (ValueError, TypeError, UnicodeError, RecursionError, binascii.Error):
        raise LoginError("stored_login_invalid") from None
    return revision, decoded


def secret_name(stack) -> str:
    """The plugin secret holding this Stack's login."""
    if (
        not isinstance(stack, str)
        or not stack
        or stack in {".", ".."}
        or any(c in stack for c in "/\\\0")
    ):
        raise LoginError("stack_unknown")
    return f"login.{stack}"


@contextlib.contextmanager
def store_lock(state):
    """Serialise check-and-commit across the hosted process and a ``--setup`` process."""
    descriptor = private_directory(state)
    try:
        fd = os.open(LOCK_FILE, os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW, 0o600, dir_fd=descriptor)
    finally:
        os.close(descriptor)
    try:
        fcntl.flock(fd, fcntl.LOCK_EX)
        yield
    finally:
        os.close(fd)


def commit(ctx, state, stack, files: dict[str, str], *, expected_revision) -> str:
    """Store ``files`` unless the store moved past ``expected_revision``; never downgrade."""
    name = secret_name(stack)
    document = encode_document(files)
    with store_lock(state):
        try:
            if expected_revision is not None:
                try:
                    current, _ = decode_document(ctx.get_secret(name))
                except LoginError:
                    # The operator replaced the store with something this code
                    # cannot read; the Run's older token must not overwrite it.
                    return "superseded"
                if current != expected_revision:
                    return "superseded"
            ctx.set_secret(name, document)
        except CallbackError:
            raise LoginError("store_unavailable") from None
    return "committed"
