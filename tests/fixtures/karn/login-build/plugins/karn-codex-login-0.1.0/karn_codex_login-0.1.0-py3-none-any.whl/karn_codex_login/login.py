"""``on_setup``: find the CLI, run its login in an isolated home, and commit the result."""

from __future__ import annotations

import contextlib
import os
import pwd
import shutil
import signal
import subprocess
import sys
import time
import uuid
from pathlib import Path

from . import store
from .store import LoginError

PLUGIN_ID = "karn-codex-login"
CLI_NAME = "codex"
LOGIN_ARGS = ["-c", 'cli_auth_credentials_store="file"', "login", "--device-auth"]
HOME_VARIABLE = "CODEX_HOME"
MANAGED_ROOT = Path("/opt/ozolith/native-cli")
INHERITED = ("PATH", "TERM", "LANG")
LOGIN_TIMEOUT = 600
SETUP_PREFIX = "setup-"


def candidate_paths() -> list[Path]:
    """Where the CLI is looked for: PATH, /usr/local/bin, ~/.local/bin, then the managed install."""
    found = []
    on_path = shutil.which(CLI_NAME)
    if on_path:
        found.append(Path(on_path))
    found.append(Path("/usr/local/bin") / CLI_NAME)
    with contextlib.suppress(KeyError):
        # HOME is the state directory here, so the service account's home comes from passwd.
        found.append(Path(pwd.getpwuid(os.getuid()).pw_dir) / ".local/bin" / CLI_NAME)
    versions = [p for p in MANAGED_ROOT.joinpath(CLI_NAME).glob("*") if p.is_dir()]
    if len(versions) == 1:
        found.append(versions[0] / CLI_NAME)
    return found


def find_cli(*, ask=None) -> str:
    """The first well-known candidate that is a regular executable, or the operator's answer."""
    for candidate in candidate_paths():
        if candidate.is_file() and os.access(candidate, os.X_OK):
            return str(candidate)
    ask = input if ask is None else ask
    try:
        answer = ask(f"{CLI_NAME} CLI path: ").strip()
    except (EOFError, OSError):
        answer = ""
    path = Path(answer) if answer else None
    if path is None or not path.is_absolute() or not path.is_file() or not os.access(path, os.X_OK):
        raise LoginError("cli_not_found")
    return str(path)


def _group_running(group) -> bool:
    for path in Path("/proc").glob("[0-9]*/stat"):
        try:
            values = path.read_text().rpartition(")")[2].split()
        except (FileNotFoundError, ProcessLookupError):
            continue
        if int(values[2]) == group and values[0] not in {"Z", "X"}:
            return True
    return False


def run_login(argv, environment, *, timeout=LOGIN_TIMEOUT) -> None:
    """Run a trusted foreground login command and stop its complete process group.

    The configured command and its credential-writing children must remain in the
    group; background services and writers escaping it require another driver.
    """
    if not argv or any(not isinstance(item, str) or "\0" in item for item in argv):
        raise LoginError("invalid_login_command")
    process = None
    handlers = {}
    caught = []

    def interrupted(signum, _frame):
        caught.append(signum)
        if process is not None:
            with contextlib.suppress(ProcessLookupError):
                os.killpg(process.pid, signum)

    try:
        for sig in (signal.SIGINT, signal.SIGTERM, signal.SIGHUP):
            handlers[sig] = signal.signal(sig, interrupted)
        process = subprocess.Popen(
            argv, env=environment, cwd=environment["HOME"], start_new_session=True
        )
        deadline = time.monotonic() + timeout
        result = None
        while not caught:
            observed = os.waitid(os.P_PID, process.pid, os.WEXITED | os.WNOHANG | os.WNOWAIT)
            if observed is not None:
                result = observed
                break
            if time.monotonic() >= deadline:
                raise LoginError("login_timeout")
            time.sleep(0.02)
        success = (
            not caught
            and result is not None
            and result.si_code == os.CLD_EXITED
            and result.si_status == 0
        )
    finally:
        try:
            if process is not None:
                # Do not reap the leader before signaling: its retained PID binds
                # the group identity until all credential writers have stopped.
                with contextlib.suppress(ProcessLookupError):
                    os.killpg(process.pid, signal.SIGKILL)
                deadline = time.monotonic() + 5
                while _group_running(process.pid):
                    if time.monotonic() >= deadline:
                        raise LoginError("login_writers_not_stopped")
                    time.sleep(0.02)
                process.wait(timeout=5)
        finally:
            for sig, handler in handlers.items():
                signal.signal(sig, handler)
    if not success:
        raise LoginError("login_failed")


def isolated_environment(state: Path, setup: Path, native: Path) -> dict[str, str]:
    """The login's environment: only PATH, TERM, LANG inherited; every home path under ``setup``."""
    environment = {key: os.environ[key] for key in INHERITED if key in os.environ}
    environment.update(
        HOME=str(setup),
        XDG_CONFIG_HOME=str(setup / ".config"),
        XDG_DATA_HOME=str(setup / ".local/share"),
        XDG_CACHE_HOME=str(setup / ".cache"),
        XDG_STATE_HOME=str(setup / ".local/state"),
    )
    environment[HOME_VARIABLE] = str(native)
    root = state.resolve()
    for key in (
        "HOME",
        "XDG_CONFIG_HOME",
        "XDG_DATA_HOME",
        "XDG_CACHE_HOME",
        "XDG_STATE_HOME",
        HOME_VARIABLE,
    ):
        if not Path(environment[key]).resolve().is_relative_to(root):
            raise LoginError("unsafe_login_home")
    return environment


def remove_setup_directories(state: Path) -> None:
    """A killed earlier setup may have left plaintext login files behind."""
    for leftover in state.glob(f"{SETUP_PREFIX}*"):
        if leftover.is_dir() and not leftover.is_symlink():
            shutil.rmtree(leftover)
        else:
            leftover.unlink()


def setup(ctx, *, ask=None, timeout=None) -> None:
    """Log in once for the Stack in context and store the result; plaintext never outlives it."""
    timeout = LOGIN_TIMEOUT if timeout is None else timeout
    state = Path(os.environ["HOME"])
    os.close(store.private_directory(state))
    stack = ctx.stack
    store.secret_name(stack)
    remove_setup_directories(state)
    cli = find_cli(ask=ask)
    setup_dir = state / f"{SETUP_PREFIX}{uuid.uuid4().hex}"
    setup_dir.mkdir(mode=0o700)
    try:
        native = setup_dir / "native"
        native.mkdir(mode=0o700)
        environment = isolated_environment(state, setup_dir, native)
        if any(native.iterdir()):
            raise LoginError("fresh_login_home_required")
        run_login([cli, *LOGIN_ARGS], environment, timeout=timeout)
        files = store.capture(native)
        store.commit(ctx, state, stack, files, expected_revision=None)
        store.write_private(
            state,
            "status.json",
            store.canonical({"harvest_failed": False, "relogin_needed": False}).encode(),
        )
    finally:
        shutil.rmtree(setup_dir, ignore_errors=True)
    print(f"{PLUGIN_ID}: login stored for Stack {stack}.")


def refused(code: str) -> None:
    print(f"{PLUGIN_ID} setup refused: {code}", file=sys.stderr, flush=True)
