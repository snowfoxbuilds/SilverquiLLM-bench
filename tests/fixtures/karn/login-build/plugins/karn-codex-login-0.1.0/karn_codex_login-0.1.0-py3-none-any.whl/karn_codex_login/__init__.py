"""The Codex subscription login Plugin (LOGIN-PLUGINS.md, ADR-0093, ADR-0102, ADR-0110).

One login per Stack, stored as the plugin secret ``login.<stack>``. Each Run gets
the Stack's login files as the CLI's home at ``/native``; after every Run the
refreshed files are harvested back, never over a newer login the operator stored.
"""

from __future__ import annotations

import contextlib
import errno
import json
import os
import shutil
import stat
import threading
from pathlib import Path

from ozolith_plugin_sdk import CallbackError, PluginError
from ozolith_plugin_sdk import Plugin as SdkPlugin

from . import login, store
from .login import CLI_NAME, HOME_VARIABLE, LOGIN_ARGS, PLUGIN_ID
from .store import ACCOUNT_FILE, ACCOUNT_KEYS, LOGIN_FILE, STORED_FILES, LoginError

__version__ = "0.1.0"
STATUS_KEY = "codex-login"
MOUNT_TARGET = "/native"
OUTPUT_TARGET = "/output"
RESULT_FILE = "result.json"
MAX_RESULT = 64 * 1024
MAX_BOOKKEEPING = 4096
WORK = "work"
MOUNTED = "mounted.json"
STATUS = "status.json"

__all__ = [
    "ACCOUNT_FILE",
    "ACCOUNT_KEYS",
    "CLI_NAME",
    "HOME_VARIABLE",
    "LOGIN_ARGS",
    "LOGIN_FILE",
    "PLUGIN_ID",
    "STATUS_KEY",
    "STORED_FILES",
    "LoginError",
    "Plugin",
    "__version__",
]


def _state_dir() -> Path:
    state = Path(os.environ["HOME"])
    os.close(store.private_directory(state))
    return state


def _read_bookkeeping(state: Path, name: str):
    """A small JSON object from the state directory, or ``None`` when absent or unreadable."""
    try:
        descriptor = store.private_directory(state)
    except LoginError:
        return None
    try:
        try:
            fd = os.open(name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=descriptor)
        except OSError:
            return None
        with os.fdopen(fd, "rb") as source:
            info = os.fstat(source.fileno())
            if not stat.S_ISREG(info.st_mode) or info.st_size > MAX_BOOKKEEPING:
                return None
            value = json.loads(source.read(MAX_BOOKKEEPING + 1))
    except (OSError, ValueError, UnicodeError, RecursionError):
        return None
    finally:
        os.close(descriptor)
    return value if isinstance(value, dict) else None


def _read_status(state: Path) -> dict[str, bool]:
    value = _read_bookkeeping(state, STATUS) or {}
    return {key: value.get(key) is True for key in ("harvest_failed", "relogin_needed")}


def _write_status(state: Path, **changes: bool) -> None:
    status = _read_status(state)
    status.update(changes)
    store.write_private(state, STATUS, store.canonical(status).encode())


def _read_mounted(state: Path):
    value = _read_bookkeeping(state, MOUNTED)
    if value is None or set(value) != {"run_id", "revision"}:
        return None
    if value["run_id"] is not None and not isinstance(value["run_id"], str):
        return None
    return value


def _clear_work(state: Path) -> None:
    work = state / WORK
    if work.is_symlink():
        work.unlink()
    elif work.exists():
        shutil.rmtree(work)
    with contextlib.suppress(FileNotFoundError):
        (state / MOUNTED).unlink()


def _harvest(ctx, state: Path, stack: str, revision) -> str:
    """Commit the working directory: committed, superseded, missing, invalid, or store_failed."""
    if not isinstance(revision, str):
        return "invalid"
    try:
        files = store.capture(state / WORK)
    except LoginError as error:
        return "missing" if str(error) == "missing_login" else "invalid"
    except OSError:
        return "invalid"
    try:
        return store.commit(ctx, state, stack, files, expected_revision=revision)
    except LoginError as error:
        if str(error) in {"store_unavailable", "login_too_large"}:
            return "store_failed"
        return "invalid"


def _settle(state: Path, outcome: str) -> None:
    """Apply the harvest outcome to ``status.json``, ``work/``, and ``mounted.json``."""
    if outcome == "committed":
        _write_status(state, harvest_failed=False)
    elif outcome in {"missing", "invalid", "store_failed"}:
        _write_status(state, harvest_failed=True)
    if outcome != "store_failed":
        _clear_work(state)


def _result_failure_code(mounts):
    """The ``failure_code`` of ``/output/result.json`` read from the mounts payload, else ``None``.

    Read from the payload, not ``ctx.read_file``: that capability serves only a
    live Run and would re-enter the runtime lock held during this dispatch.
    """
    source = None
    for row in mounts:
        if isinstance(row, dict) and row.get("Target") == OUTPUT_TARGET:
            source = row.get("Source")
    if not isinstance(source, str) or not os.path.isabs(source):
        return None
    try:
        descriptor = os.open(source, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    except OSError:
        return None
    try:
        fd = os.open(RESULT_FILE, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=descriptor)
        with os.fdopen(fd, "rb") as result:
            info = os.fstat(result.fileno())
            if not stat.S_ISREG(info.st_mode) or info.st_size > MAX_RESULT:
                return None
            value = json.loads(result.read(MAX_RESULT + 1))
    except (OSError, ValueError, UnicodeError, RecursionError):
        return None
    finally:
        os.close(descriptor)
    if not isinstance(value, dict):
        return None
    return {"failure_code": value.get("failure_code")}


class Plugin(SdkPlugin):
    def __init__(self):
        self._lock = threading.Lock()

    def on_setup(self, ctx):
        try:
            login.setup(ctx)
        except LoginError as error:
            login.refused(str(error))
            raise
        except CallbackError as error:
            login.refused(f"store_unavailable ({error.code})")
            raise
        except OSError as error:
            # Only the errno name: a path or message could name a login file.
            login.refused(f"os_error ({errno.errorcode.get(error.errno, 'unknown')})")
            raise

    def before_container_mount(self, mounts, ctx):
        with self._lock:
            try:
                return self._mount(mounts, ctx)
            except LoginError as error:
                raise PluginError(str(error)) from None

    def _mount(self, mounts, ctx):
        if ctx.configuration != {}:
            raise PluginError("unsupported_configuration")
        state = _state_dir()
        stack = ctx.stack
        store.secret_name(stack)
        work = state / WORK
        mounted = _read_mounted(state)
        if (state / MOUNTED).exists() or work.exists():
            # A Stack is serial: whatever the last Run left is over, so a pending
            # harvest is retried before its files are replaced.
            if work.is_dir() and not work.is_symlink() and any(work.iterdir()):
                outcome = _harvest(ctx, state, stack, mounted["revision"] if mounted else None)
                _settle(state, outcome)
                if outcome == "store_failed":
                    raise PluginError("harvest_pending")
            else:
                _clear_work(state)
        try:
            text = ctx.get_secret(store.secret_name(stack))
        except CallbackError:
            raise PluginError("login_missing") from None
        revision, files = store.decode_document(text)
        _clear_work(state)
        work.mkdir(mode=0o700)
        store.write_files(work, files)
        store.write_private(
            state, MOUNTED, store.canonical({"run_id": ctx.run_id, "revision": revision}).encode()
        )
        return [
            *mounts,
            {
                "Type": "bind",
                "Source": str(work.resolve()),
                "Target": MOUNT_TARGET,
                "ReadOnly": False,
            },
        ]

    def after_container_exit(self, mounts, ctx):
        with self._lock:
            state = _state_dir()
            stack = ctx.stack
            store.secret_name(stack)
            mounted = _read_mounted(state)
            if mounted is None:
                if (state / MOUNTED).exists():
                    # Unreadable bookkeeping: the token in work/ cannot be matched
                    # to a revision, so it is never committed over the store.
                    _settle(state, "invalid")
                return None
            if mounted["run_id"] != ctx.run_id:
                return None
            outcome = _harvest(ctx, state, stack, mounted["revision"])
            _settle(state, outcome)
            result = _result_failure_code(mounts)
            if result is not None:
                _write_status(state, relogin_needed=result["failure_code"] == "authentication")
            return None

    def on_render_status(self, rows, ctx):
        try:
            status = _read_status(Path(os.environ["HOME"]))
        except (KeyError, OSError):
            status = {}
        flags = [
            text
            for key, text in (
                ("relogin_needed", "relogin needed"),
                ("harvest_failed", "harvest failed"),
            )
            if status.get(key)
        ]
        rendered = []
        for row in rows:
            item = dict(row)
            if flags:
                item[STATUS_KEY] = ", ".join(flags)
            rendered.append(item)
        return rendered
