import sys

from ozolith_plugin_sdk import serve

from karn_codex_login import Plugin

MANIFEST = {
    "id": "karn-codex-login",
    "version": "0.1.0",
    "sdk_major": 1,
    "hooks": ["on_setup", "before_container_mount", "after_container_exit", "on_render_status"],
}

sys.exit(serve(Plugin(), MANIFEST))
