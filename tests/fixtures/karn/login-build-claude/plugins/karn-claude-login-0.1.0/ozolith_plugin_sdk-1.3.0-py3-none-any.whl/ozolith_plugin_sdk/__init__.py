"""The Ozolith Plugin Contract (ADR-0102).

A plugin process speaks newline-delimited JSON on its private stdio. The daemon
sends ``{"id", "method", "params"}`` and the plugin answers ``{"id", "result"}``
or ``{"id", "error"}``. ``plugin.hello`` returns the manifest identity and
``plugin.activate`` is a side-effect-free readiness check. ``plugin.invoke``
carries ``{"hook", "context", "payload"}`` and calls the named hook with the
payload's argument and a ``Context``; ``on_setup`` is never invoked this way,
only by the operator's one-shot ``--setup`` process.

Requests are served concurrently, one thread each: a hook that calls back into
the daemon (``ctx.start_run`` from ``on_poll``) makes the daemon dispatch other
hooks to this same process before it returns, so a plugin's hooks must be safe
to run on different threads.
"""

from __future__ import annotations

import dataclasses
import json
import os
import sys
import threading

from .context import CallbackError, Context, PluginError

SDK_MAJOR = 1
# The CPython minor the Node Daemon and every Plugin environment run on (see
# ADR-0111). Karn and Ozolith's installers read this line without importing the
# module, so it must stay one top-level assignment of a string literal "3.N".
PYTHON_MINOR = "3.13"
HOOKS = (
    "on_install",
    "on_setup",
    "on_get_secret",
    "on_network_egress",
    "before_container_mount",
    "after_container_exit",
    "on_poll",
    "on_render_status",
    "on_construct_build",
)
MAX_MESSAGE = 1024 * 1024
HELLO_KEYS = ("id", "version", "sdk_major", "hooks")
# The payload key each hook's argument travels under; None for a hook without one.
HOOK_ARGUMENT = {
    "on_install": None,
    "on_setup": None,
    "on_get_secret": "secret",
    "on_network_egress": "request",
    "before_container_mount": "mounts",
    "after_container_exit": "mounts",
    "on_poll": None,
    "on_render_status": "rows",
    "on_construct_build": "build",
}


class Plugin:
    """Override the hooks the manifest declares; every other hook is its identity."""

    def on_install(self, ctx):
        return None

    def on_setup(self, ctx):
        return None

    def on_get_secret(self, secret, ctx):
        return secret

    def on_network_egress(self, request, ctx):
        return request

    def before_container_mount(self, mounts, ctx):
        return mounts

    def after_container_exit(self, mounts, ctx):
        return None

    def on_poll(self, ctx):
        return None

    def on_render_status(self, rows, ctx):
        return rows

    def on_construct_build(self, build, ctx):
        """Prepare this Plugin's data for a Construct during ``karn build`` (ADR-0109).

        The one hook Karn calls and the Node never does. ``build`` is passed
        through unvalidated::

            {
                "configuration": {...},     # this Plugin's row in the definition's plugins[]
                "entry_dir": "<abs path>",  # read-only view of the Construct Entry
                "trees": {"knowledge/<cli>/<name>": "<abs path>", "policy/<cli>/<name>": "..."},
                                            # each tree the configuration references, keyed
                                            # by the reference string -> read-only view
                "output_dir": "<abs path>", # empty; what the hook writes here is the
                                            # Construct's plugin data, read back on the
                                            # Node through ctx.definition_data()
            }

        Returns a JSON object of additions to this Plugin's own configuration
        (for example ``{"knowledge_digest": "sha256:..."}``); ``{}`` adds none.
        ``ctx`` carries no capability during a build: there is no socket.
        """
        return {}


def encode(value):
    try:
        data = json.dumps(value, separators=(",", ":"), allow_nan=False).encode() + b"\n"
    except (ValueError, TypeError):
        raise PluginError("invalid_message") from None
    if len(data) > MAX_MESSAGE:
        raise PluginError("message_too_large")
    return data


def decode(raw):
    if len(raw) > MAX_MESSAGE or not raw.endswith(b"\n"):
        raise PluginError("invalid_message")
    try:
        value = json.loads(raw)
    except (ValueError, UnicodeError, RecursionError):
        raise PluginError("invalid_message") from None
    if (
        not isinstance(value, dict)
        or set(value) != {"id", "method", "params"}
        or not isinstance(value["id"], str)
        or not isinstance(value["method"], str)
    ):
        raise PluginError("invalid_message")
    return value


def identity(manifest):
    return {key: manifest[key] for key in HELLO_KEYS}


def invoke(plugin, manifest, params, *, environ):
    """Call the hook ``params`` names; its return value is the reply's result."""
    if not isinstance(params, dict) or params.get("hook") not in HOOK_ARGUMENT:
        raise PluginError("unknown_hook")
    hook = params["hook"]
    if hook == "on_setup":
        # Setup is the operator's one-shot ``--setup`` process on a terminal,
        # never a call on the hosted process (ADR-0102).
        raise PluginError("setup_is_one_shot")
    context = params.get("context")
    context = context if isinstance(context, dict) else {}
    configuration = context.get("configuration")
    ctx = dataclasses.replace(
        Context.from_environ(environ),
        run_id=context.get("run_id"),
        stack=context.get("stack") or environ.get("THEOZOLITH_STACK"),
        configuration=configuration if isinstance(configuration, dict) else {},
    )
    key = HOOK_ARGUMENT[hook]
    if key is None:
        return getattr(plugin, hook)(ctx)
    payload = params.get("payload")
    if not isinstance(payload, dict) or key not in payload:
        raise PluginError("invalid_payload")
    return getattr(plugin, hook)(payload[key], ctx)


def handle(plugin, manifest, request, *, environ=None):
    """One request's reply."""
    method = request["method"]
    if method == "plugin.hello":
        return {"id": request["id"], "result": identity(manifest)}
    if method == "plugin.activate":
        return {"id": request["id"], "result": {"ready": True}}
    if method == "plugin.invoke":
        try:
            result = invoke(
                plugin,
                manifest,
                request["params"],
                environ=os.environ if environ is None else environ,
            )
        except PluginError as error:
            return {"id": request["id"], "error": error.code}
        except Exception:
            return {"id": request["id"], "error": "hook_failed"}
        return {"id": request["id"], "result": result}
    return {"id": request["id"], "error": "unknown_method"}


def serve(plugin, manifest, *, stdin=None, stdout=None, argv=None, environ=None):
    """Run the protocol loop, or ``on_setup`` once when invoked with ``--setup``.

    Returns the process exit status; a malformed or oversize line fails only
    that request (the daemon times the call out), never the process.
    """
    argv = sys.argv[1:] if argv is None else list(argv)
    environ = os.environ if environ is None else environ
    if argv == ["--setup"]:
        try:
            plugin.on_setup(Context.from_environ(environ))
        except Exception:
            return 1
        return 0
    if argv:
        return 2
    stdin = sys.stdin.buffer if stdin is None else stdin
    stdout = sys.stdout.buffer if stdout is None else stdout
    write_lock = threading.Lock()

    def answer(request):
        try:
            reply = encode(handle(plugin, manifest, request, environ=environ))
        except PluginError as error:
            reply = encode({"id": request["id"], "error": error.code})
        with write_lock:
            stdout.write(reply)
            stdout.flush()

    while True:
        raw = stdin.readline(MAX_MESSAGE + 1)
        if not raw:
            return 0
        try:
            request = decode(raw)
        except PluginError:
            continue
        threading.Thread(target=answer, args=(request,), daemon=True).start()


__all__ = [
    "HOOKS",
    "HOOK_ARGUMENT",
    "MAX_MESSAGE",
    "PYTHON_MINOR",
    "SDK_MAJOR",
    "CallbackError",
    "Context",
    "Plugin",
    "PluginError",
    "decode",
    "encode",
    "handle",
    "identity",
    "invoke",
    "serve",
]
