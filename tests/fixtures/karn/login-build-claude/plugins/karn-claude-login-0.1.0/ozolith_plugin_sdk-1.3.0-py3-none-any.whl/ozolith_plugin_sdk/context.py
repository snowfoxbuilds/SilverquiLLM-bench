"""What a hook knows about its call site, and the Stack-scoped capability it holds.

The daemon serves each hosted plugin process one Unix socket, named by
``THEOZOLITH_CALLBACK_SOCKET`` with the capability token in
``THEOZOLITH_CALLBACK_TOKEN``. The socket is bound to one (Stack, plugin), so
no call names a Stack or a plugin: scope is by construction (ADR-0102). Each
call is one newline-delimited JSON round trip, ``{"token", "method", "params"}``
answered by ``{"result": ...}`` or ``{"error": <code>}``.
"""

from __future__ import annotations

import base64
import json
import os
import socket
from dataclasses import dataclass, field

MAX_MESSAGE = 1024 * 1024
CALL_TIMEOUT = 30.0
RUN_TIMEOUT = 300.0


class PluginError(Exception):
    def __init__(self, code):
        self.code = code
        super().__init__(code)


def _connect(connection, path):
    # A socket nested under a long state root exceeds sun_path (108 bytes on
    # Linux); connecting through its directory's descriptor keeps the path short.
    if len(path.encode()) < 100:
        connection.connect(path)
        return
    fd = os.open(os.path.dirname(path), os.O_RDONLY | os.O_DIRECTORY)
    try:
        connection.connect(f"/proc/self/fd/{fd}/{os.path.basename(path)}")
    finally:
        os.close(fd)


class CallbackError(PluginError):
    """The daemon refused a capability call; ``code`` is its closed error code."""


@dataclass(frozen=True)
class Context:
    """What a hook knows about its call site.

    ``configuration`` is the plugin's own row from the Stack's current
    Construct Definition: the table ``karn build`` emitted, including whatever
    ``on_construct_build`` added to it. It is ``{}`` when the row sets none and
    on the one-shot ``--setup`` path, which runs outside any hook call.
    """

    node: str | None = None
    stack: str | None = None
    definition_id: str | None = None
    definition_revision: str | None = None
    plugin_id: str | None = None
    run_id: str | None = None
    configuration: dict = field(default_factory=dict)
    callback_socket: str | None = field(default=None, repr=False, compare=False)
    callback_token: str | None = field(default=None, repr=False, compare=False)

    @classmethod
    def from_environ(cls, environ):
        return cls(
            node=environ.get("THEOZOLITH_NODE_NAME"),
            stack=environ.get("THEOZOLITH_STACK"),
            definition_id=environ.get("THEOZOLITH_DEFINITION_ID"),
            definition_revision=environ.get("THEOZOLITH_DEFINITION_REVISION"),
            plugin_id=environ.get("THEOZOLITH_PLUGIN_ID"),
            callback_socket=environ.get("THEOZOLITH_CALLBACK_SOCKET"),
            callback_token=environ.get("THEOZOLITH_CALLBACK_TOKEN"),
        )

    def _call(self, method, params, *, timeout=CALL_TIMEOUT):
        if not self.callback_socket or not self.callback_token:
            raise CallbackError("callback_unavailable")
        try:
            data = json.dumps(
                {"token": self.callback_token, "method": method, "params": params},
                separators=(",", ":"),
                allow_nan=False,
            ).encode()
        except (TypeError, ValueError):
            raise CallbackError("invalid_message") from None
        if len(data) >= MAX_MESSAGE:
            raise CallbackError("message_too_large")
        try:
            with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as connection:
                connection.settimeout(timeout)
                _connect(connection, self.callback_socket)
                connection.sendall(data + b"\n")
                connection.shutdown(socket.SHUT_WR)
                raw = b""
                while not raw.endswith(b"\n") and len(raw) <= MAX_MESSAGE:
                    part = connection.recv(65536)
                    if not part:
                        break
                    raw += part
        except (OSError, ValueError):
            raise CallbackError("callback_unavailable") from None
        try:
            reply = json.loads(raw)
        except ValueError:
            raise CallbackError("invalid_reply") from None
        if not isinstance(reply, dict) or set(reply) not in ({"result"}, {"error"}):
            raise CallbackError("invalid_reply")
        if "error" in reply:
            raise CallbackError(reply["error"])
        return reply["result"]

    # -- secrets ----------------------------------------------------------------

    def get_secret(self, name):
        return self._call("get_secret", {"name": name})["value"]

    def set_secret(self, name, value):
        return self._call("set_secret", {"name": name, "value": value})["stored"]

    def list_secrets(self):
        return list(self._call("list_secrets", {})["names"])

    # -- plugin data ------------------------------------------------------------

    def definition_data(self):
        """The read-only path of this Plugin's data for the Stack's current revision."""
        return self._call("definition_data", {})["path"]

    # -- the next Run's environment and the live Run's mounts --------------------

    def set_run_env(self, mapping):
        return self._call("set_run_env", {"mapping": dict(mapping)})["staged"]

    def read_file(self, mount, path, *, offset=0, limit=65536):
        result = self._call(
            "read_file", {"mount": mount, "path": path, "offset": offset, "limit": limit}
        )
        return base64.b64decode(result["data_base64"]), result["size"], result["eof"]

    def write_file(self, mount, path, data):
        if isinstance(data, str):
            data = data.encode()
        return self._call(
            "write_file",
            {"mount": mount, "path": path, "data": base64.b64encode(bytes(data)).decode()},
        )["written"]

    # -- Runs on the Stack in context --------------------------------------------

    def start_run(self, inputs=None):
        return self._call("start_run", {"inputs": dict(inputs or {})}, timeout=RUN_TIMEOUT)[
            "run_id"
        ]

    def run_status(self, run_id):
        return self._call("run_status", {"run_id": run_id})

    def stop_run(self, run_id):
        return self._call("stop_run", {"run_id": run_id}, timeout=RUN_TIMEOUT)
